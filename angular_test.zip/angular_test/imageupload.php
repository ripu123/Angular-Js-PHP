<?php
session_start();
if (!isset($_SESSION["email"]))
   {
      header("location: index.php");
   }
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset = "UTF-8" name = "viewport" content = "width=device-width, initial-scale=1"/>
		<title>Image Upload Using AngularJs</title>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
  <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.7/angular.min.js"></script>
	</head>
<body ng-app="myModule" ng-controller="myController">
	<nav class = "navbar navbar-default">
		<div class = "container-fluid">
		</div>
	</nav>
	<div class = "row">
		<div class = "col-md-3"></div>
		<div class = "col-md-6 well">
		<h3 class = "text-primary">Simple Image Upload Using AngularJs</h3>
		<hr style = "boreder-top:1px dotted #000;"/>
			<form ng-submit="submit()" name="form" role="form">
				<div class = "form-inline">	
					<input ng-model="form.image" class = "form-control" type="file" accept="image/*" onchange="angular.element(this).scope().uploadedFile(this)" style="width:400px" >
					<button class = "btn btn-primary"><span class = "glyphicon glyphicon-upload"></span> Upload</button>
					<a href = "display.php" >See All Upload Images</a>
				</div>	
				<br/>
				<center><img ng-src="{{image_source}}" style="width:600px;"></center>
			</form>
		</div>	
	</div>	
</body>
<script>
var app =  angular.module('myModule',[]);
 
	    app.controller('myController', function($scope, $http) {
 
	      $scope.form = [];
	      $scope.files = [];
 
	      $scope.submit = function() {
	      	$scope.form.image = $scope.files[0];
 
	      	$http({
			  method  : 'POST',
			  url     : 'upload.php',
			  processData: false,
			  transformRequest: function (data) {
			      var formData = new FormData();
			      formData.append("image", $scope.form.image);  
			      return formData;  
			  },  
			  data : $scope.form,
			  headers: {
			         'Content-Type': undefined
			  }
		   }).then(function(data){
				alert("Successfully Upload An Image!");
				window.location = "index.php";
		   });
 
	      };
 
	      $scope.uploadedFile = function(element) {
		    $scope.currentFile = element.files[0];
		    var reader = new FileReader();
		    reader.onload = function(event) {
		      $scope.image_source = event.target.result
		      $scope.$apply(function($scope) {
		        $scope.files = element.files;
		      });
		    }
                    reader.readAsDataURL(element.files[0]);
		  }
	    });
</script>
</html>