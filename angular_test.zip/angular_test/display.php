<?php
session_start();
if (!isset($_SESSION["email"]))
   {
      header("location: index.php");
   }
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset = "UTF-8" name = "viewport" content = "width=device-width, initial-scale=1"/>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.7/angular.min.js"></script>
  
  <script src="ng-infinite-scroll.min.js"></script>
  <script>
	var fetch = angular.module('myapp', ['infinite-scroll']);

fetch.controller('fetchCtrl', ['$scope', '$http', function ($scope, $http) {

  // Variables
  $scope.row = 0;
  $scope.rowperpage = 3;
  $scope.posts = [];
  $scope.busy = false;
  $scope.loading = false;

  // Fetch data
  $scope.getPosts = function(){

  if ($scope.busy) return;

    $scope.busy = true;

    // Fetch data
    $http({
      method: 'post',
      url: 'ajaxfile.php',
      data: {row:$scope.row,rowperpage:$scope.rowperpage}
    }).then(function successCallback(response) {

      if(response.data !='' ){
         // New row value 
         $scope.row+=$scope.rowperpage;

         $scope.loading = true;
         setTimeout(function() {
            $scope.$apply(function(){

              // Assign response to posts Array 
              angular.forEach(response.data,function(item) {
                 $scope.posts.push(item);
              });
              $scope.busy = false;
              $scope.loading = false;
            });

         },500);
      }

    });
  }

  // Call function
  $scope.getPosts();

}]);
</script>
	</head>
<body ng-app='myapp' ng-controller='fetchCtrl' >
     <div class="container" infinite-scroll="getPosts()" >
 
       <div class="post" ng-repeat='post in posts'>
          <img src="images/{{post.photo_name}}" alt="post.photo_name" height="300" width="300">
          
       </div>

       <div ng-show='loading' class='loading'>Loading...</div>
     </div>

  </body>
</html>
