<?php
	if(!empty($_FILES['image'])){
		$conn  = new mysqli("localhost", "precisio_angular", "guwahati@1982", "precisio_angular_test") or die(mysqli_error());
		$path = pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
                $image = time().'.'.$path;
                move_uploaded_file($_FILES["image"]["tmp_name"], 'images/'.$image);
				$conn->query("INSERT INTO `photo` (photo_name) VALUES('$image')") or die(mysqli_error());
	}else{
		echo "<script>Error!</script>";
	}
?>