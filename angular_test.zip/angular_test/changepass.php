<?php



//index.php



session_start();



?>

<!DOCTYPE html>

<html>

 <head>

  <title>Angular Test</title>

  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

  <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.7/angular.min.js"></script>

  <style>

  .form_style

  {

   width: 600px;

   margin: 0 auto;

  }

  </style>

  </head>

 <body>
<div ng-app="crudApp" ng-controller="crudController" class="container form_style">
 <h3 align="center">AngularJS Register Login</h3>

 <div class="alert {{alertClass}} alert-dismissible" ng-show="alertMsg">
    <a href="#" class="close" ng-click="closeMsg()" aria-label="close">&times;</a>
    {{alertMessage}}
   </div>

 <div class="panel panel-default">

    <div class="panel-heading">

     <h3 class="panel-title">Change Password</h3>

    </div>

    <div class="panel-body">

     <form method="post" ng-submit="submitLogin()">

      <!--<input type="hidden" name="email" ng-model="loginData.email" class="form-control" value="<?php //echo $_SESSION["email"];?>" />-->
      <input type="hidden" name="email"  class="form-control" value="<?php echo $_SESSION["email"];?>" />
      <div class="form-group">

       <label>Enter Your New Password</label>

       <input type="password" name="password" ng-model="loginData.password" class="form-control"  />

      </div>

      <div class="form-group" align="center">

       <input type="submit" name="login" class="btn btn-primary" value="Change Password" />

       <br />

      </div>

     </form>

    </div>

   </div>

   </div>

   </body>

   </html>

   

   <script>

var app = angular.module('crudApp', []);

app.controller('crudController', function($scope, $http){
$scope.closeMsg = function(){
  $scope.alertMsg = false;
 };



$scope.submitLogin = function(){


  $http({

   method:"POST",

   url:"pass.php",

   data:$scope.loginData

  }).success(function(data){

  
   if(data.error != '')

   {

    $scope.alertMsg = true;

    $scope.alertClass = 'alert-danger';

    $scope.alertMessage = data.error;

   }

   else

   {

    //location.reload();

   }

  });

 };	

	

});

	

</script>