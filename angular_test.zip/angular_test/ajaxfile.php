<?php

// configuration
$con  = new mysqli("localhost", "precisio_angular", "guwahati@1982", "precisio_angular_test") or die(mysqli_error());

$data = json_decode(file_get_contents("php://input"));

$row = $data->row;
$rowperpage = $data->rowperpage;

// Fetch data
$query = 'SELECT * FROM photo limit '.$row.','.$rowperpage;

$result = mysqli_query($con,$query);

$data = array();
while($row = mysqli_fetch_assoc($result)){
   $id = $row['photo_id'];
   $title = $row['photo_name'];
   //$content = $row['content'];
   //$shortcontent = substr($content, 0, 160)."...";
  // $link = $row['link'];

   $data[] = array(
          "id"=>$id,
          "photo_name"=>$title);
          //"shortcontent"=>$shortcontent,
          //"link"=>$link,
          //"content"=>$content);

}

echo json_encode($data);

?>