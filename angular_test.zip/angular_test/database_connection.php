<?php



$connect = new PDO("mysql:host=localhost;dbname=precisio_angular_test", "precisio_angular", "guwahati@1982");



?>